import React from 'react';
import { Utensils, Star, Phone, Mail, CircleCheck, CircleX } from 'lucide-react'; // Import necessary icons

const DashboardOverview = ({ restaurant }) => {
  return (
    <section className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">Restaurant Profile Overview</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="flex items-center bg-gray-50 p-4 rounded-lg shadow-sm">
          <Utensils className="w-6 h-6 text-orange-500 mr-3" />
          <div>
            <p className="text-sm text-gray-600">Restaurant Name</p>
            <p className="font-medium text-gray-800">{restaurant.name}</p>
          </div>
        </div>
        <div className="flex items-center bg-gray-50 p-4 rounded-lg shadow-sm">
          {restaurant.status === 'Open' ? <CircleCheck className="w-6 h-6 text-green-500 mr-3" /> : <CircleX className="w-6 h-6 text-red-500 mr-3" />}
          <div>
            <p className="text-sm text-gray-600">Status</p>
            <p className={`font-medium ${restaurant.status === 'Open' ? 'text-green-700' : 'text-red-700'}`}>{restaurant.status}</p>
          </div>
        </div>
        <div className="flex items-center bg-gray-50 p-4 rounded-lg shadow-sm">
          <Star className="w-6 h-6 text-yellow-500 mr-3" />
          <div>
            <p className="text-sm text-gray-600">Rating</p>
            <p className="font-medium text-gray-800">{restaurant.rating} / 5</p>
          </div>
        </div>
        <div className="flex items-center bg-gray-50 p-4 rounded-lg shadow-sm">
          {/* You might want to replace this div with a location icon from lucide-react */}
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-map-pin w-6 h-6 text-blue-500 mr-3"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
          <div>
            <p className="text-sm text-gray-600">Address</p>
            <p className="font-medium text-gray-800">{restaurant.address}</p>
          </div>
        </div>
        <div className="flex items-center bg-gray-50 p-4 rounded-lg shadow-sm">
          <Phone className="w-6 h-6 text-purple-500 mr-3" />
          <div>
            <p className="text-sm text-gray-600">Contact Number</p>
            <p className="font-medium text-gray-800">{restaurant.contact}</p>
          </div>
        </div>
        <div className="flex items-center bg-gray-50 p-4 rounded-lg shadow-sm">
          <Mail className="w-6 h-6 text-indigo-500 mr-3" />
          <div>
            <p className="text-sm text-gray-600">Email</p>
            <p className="font-medium text-gray-800">{restaurant.email}</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DashboardOverview;