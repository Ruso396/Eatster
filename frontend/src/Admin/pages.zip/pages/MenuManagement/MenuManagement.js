import React from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';

const MenuManagement = ({ menuItems }) => {
  return (
    <section className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">Menu Management</h3>
      <div className="mb-6">
        <h4 className="text-lg font-medium text-gray-700 mb-3">Add New Menu Item</h4>
        <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input type="text" placeholder="Item Name" className="border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          <input type="text" placeholder="Category" className="border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          <input type="number" placeholder="Price (₹)" className="border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          <div className="flex items-center">
            <label htmlFor="itemImage" className="block text-sm font-medium text-gray-700 mr-2">Image:</label>
            <input type="file" id="itemImage" className="text-sm text-gray-500" />
          </div>
          <div className="col-span-full flex items-center">
            <input type="checkbox" id="available" className="mr-2 rounded text-orange-500 focus:ring-orange-500" defaultChecked />
            <label htmlFor="available" className="text-sm text-gray-700">Available</label>
          </div>
          <button type="submit" className="col-span-full bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 transition-colors duration-200 flex items-center justify-center">
            <Plus className="w-4 h-4 mr-2" /> Add Item
          </button>
        </form>
      </div>

      <h4 className="text-lg font-medium text-gray-700 mb-3">Current Menu Items</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {menuItems.map((item) => (
          <div key={item.id} className="bg-gray-50 p-4 rounded-lg shadow-sm flex items-center space-x-4">
            <img src={item.image} alt={item.name} className="w-16 h-16 rounded-md object-cover" />
            <div className="flex-1">
              <p className="font-semibold text-gray-800">{item.name}</p>
              <p className="text-sm text-gray-600">{item.category} - ₹{item.price}</p>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                item.available ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {item.available ? 'Available' : 'Unavailable'}
              </span>
            </div>
            <div className="flex space-x-2">
              <button className="text-blue-500 hover:text-blue-700"><Pencil className="w-4 h-4" /></button>
              <button className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default MenuManagement;