import React from 'react';
import { FileText } from 'lucide-react';

const Settings = ({ restaurant, setRestaurant }) => {
  // You would typically have state here to manage form inputs and then update on submit
  // For simplicity, we're using defaultValue and not implementing actual form submission logic here.

  return (
    <section className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">Settings</h3>

      <div className="mb-6">
        <h4 className="text-lg font-medium text-gray-700 mb-3">Restaurant Details</h4>
        <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="col-span-full">
            <label htmlFor="restaurantName" className="block text-sm font-medium text-gray-700">Restaurant Name</label>
            <input type="text" id="restaurantName" defaultValue={restaurant.name} className="mt-1 block w-full border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          </div>
          <div>
            <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700">Contact Number</label>
            <input type="text" id="contactNumber" defaultValue={restaurant.contact} className="mt-1 block w-full border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          </div>
          <div>
            <label htmlFor="emailAddress" className="block text-sm font-medium text-gray-700">Email Address</label>
            <input type="email" id="emailAddress" defaultValue={restaurant.email} className="mt-1 block w-full border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          </div>
          <div className="col-span-full">
            <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
            <textarea id="address" defaultValue={restaurant.address} rows="3" className="mt-1 block w-full border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500 resize-none"></textarea>
          </div>
          <button type="submit" className="col-span-full bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 transition-colors duration-200">Save Restaurant Details</button>
        </form>
      </div>

      <div className="mb-6">
        <h4 className="text-lg font-medium text-gray-700 mb-3">Bank Details</h4>
        <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="accountName" className="block text-sm font-medium text-gray-700">Account Holder Name</label>
            <input type="text" id="accountName" defaultValue="John Doe" className="mt-1 block w-full border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          </div>
          <div>
            <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700">Account Number</label>
            <input type="text" id="accountNumber" defaultValue="XXXXXXXXX1234" className="mt-1 block w-full border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          </div>
          <div>
            <label htmlFor="ifscCode" className="block text-sm font-medium text-gray-700">IFSC Code</label>
            <input type="text" id="ifscCode" defaultValue="BANK0001234" className="mt-1 block w-full border border-gray-300 p-2 rounded-md focus:ring-orange-500 focus:border-orange-500" />
          </div>
          <button type="submit" className="col-span-full bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 transition-colors duration-200">Save Bank Details</button>
        </form>
      </div>

      <div>
        <h4 className="text-lg font-medium text-gray-700 mb-3">FSSAI Certificate</h4>
        <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg shadow-sm">
          <div className="flex items-center">
            <FileText className="w-6 h-6 text-gray-600 mr-3" />
            <p className="text-gray-700">FSSAI_Certificate_2024.pdf</p>
          </div>
          <input type="file" className="text-sm text-gray-500" />
        </div>
      </div>
    </section>
  );
};

export default Settings;