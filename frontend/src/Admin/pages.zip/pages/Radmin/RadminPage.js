import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import AdminSidebar from '../Sidebar/AdminSidebar';
import AdminHeader from '../AdminHeader/AdminHeader';
import DashboardOverview from '../DashboardOverview/DashboardOverview';
import Settings from '../Settings/Settings';
import ReviewsFeedback from '../ReviewsFeedback/ReviewsFeedback';
import OperatingHours from '../OperatingHours/OperatingHours';
import SalesAnalytics from '../SalesAnalytics/SalesAnalytics';
import MenuManagement from '../MenuManagement/MenuManagement';
import LiveOrders from '../LiveOrders/LiveOrders';

const RadminPage = () => {
  const navigate = useNavigate();
  const { section } = useParams(); // Get section from URL
  const [activeSection, setActiveSection] = useState(section || 'overview');

  useEffect(() => {
    if (section !== activeSection) {
      setActiveSection(section || 'overview');
    }
  }, [section]);

  const [restaurant, setRestaurant] = useState({
    logo: 'https://placehold.co/80x80/000/FFF?text=LOGO',
    name: 'Little Hearts',
    owner: 'lakshka',
    status: 'Open',
    rating: 4.5,
    address: '123 Food Street, Culinary City',
    contact: '+91 98765 43210',
    email: 'rulux@gmail.com',
  });

  const [orders, setOrders] = useState({
    incoming: [],
    preparing: [],
    dispatched: [],
    completed: [],
  });

  const [menuItems, setMenuItems] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [salesData, setSalesData] = useState([]);

  const toggleRestaurantStatus = () => {
    setRestaurant(prev => ({
      ...prev,
      status: prev.status === 'Open' ? 'Closed' : 'Open',
    }));
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return <DashboardOverview restaurant={restaurant} />;
      case 'orders':
        return <LiveOrders orders={orders} setOrders={setOrders} />;
      case 'menu':
        return <MenuManagement menuItems={menuItems} setMenuItems={setMenuItems} />;
      case 'analytics':
        return <SalesAnalytics salesData={salesData} />;
      case 'hours':
        return <OperatingHours restaurantStatus={restaurant.status} toggleRestaurantStatus={toggleRestaurantStatus} />;
      case 'reviews':
        return <ReviewsFeedback reviews={reviews} />;
      case 'settings':
        return <Settings restaurant={restaurant} setRestaurant={setRestaurant} />;
      default:
        return <DashboardOverview restaurant={restaurant} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50 font-inter">
      <AdminSidebar currentPath={activeSection} navigate={navigate} restaurant={restaurant} />
      <main className="flex-1 p-8">
        <AdminHeader activeSection={activeSection} restaurantStatus={restaurant.status} toggleRestaurantStatus={toggleRestaurantStatus} />
        {renderSection()}
      </main>
    </div>
  );
};

export default RadminPage;
