import React from 'react';
import { Star } from 'lucide-react';

const ReviewsFeedback = ({ reviews }) => {
  return (
    <section className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">Reviews and Feedback</h3>
      <div className="space-y-4">
        {reviews.length > 0 ? (
          reviews.map((review) => (
            <div key={review.id} className="bg-gray-50 p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <p className="font-semibold text-gray-800">{review.customer}</p>
                <div className="flex items-center">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                  ))}
                  {[...Array(5 - review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-gray-300" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 mb-2">{review.comment}</p>
              <p className="text-xs text-gray-500 text-right">Reviewed on: {review.date}</p>
            </div>
          ))
        ) : (
          <p className="text-gray-500 text-center py-8">No reviews yet.</p>
        )}
      </div>
    </section>
  );
};

export default ReviewsFeedback;