import React, { useState } from 'react';
import { CheckCircle, XCircle, Truck, Package } from 'lucide-react';

const LiveOrders = ({ orders }) => {
  const [activeOrderTab, setActiveOrderTab] = useState('incoming');

  return (
    <section className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">Live Order Management</h3>
      <div className="flex border-b border-gray-200 mb-4">
        {['incoming', 'preparing', 'dispatched', 'completed'].map((tab) => (
          <button
            key={tab}
            className={`px-4 py-2 text-sm font-medium transition-colors duration-200 ${
              activeOrderTab === tab
                ? 'border-b-2 border-orange-500 text-orange-600'
                : 'text-gray-600 hover:text-gray-800'
            }`}
            onClick={() => setActiveOrderTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)} ({orders[tab].length})
          </button>
        ))}
      </div>
      <div className="space-y-4">
        {orders[activeOrderTab].length > 0 ? (
          orders[activeOrderTab].map((order) => (
            <div key={order.id} className="bg-gray-50 p-4 rounded-lg shadow-sm flex justify-between items-center">
              <div>
                <p className="font-semibold text-gray-800">Order #{order.id}</p>
                <p className="text-sm text-gray-600">Customer: {order.customer}</p>
                <p className="text-sm text-gray-600">Items: {order.items}</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-lg text-orange-600">₹{order.total}</p>
                <p className="text-xs text-gray-500">{order.time}</p>
                <div className="mt-2 flex space-x-2">
                  {activeOrderTab === 'incoming' && (
                    <button className="bg-green-500 text-white px-3 py-1 rounded-md text-xs hover:bg-green-600"><CheckCircle className="inline-block w-3 h-3 mr-1" /> Accept</button>
                  )}
                  {activeOrderTab === 'preparing' && (
                    <button className="bg-blue-500 text-white px-3 py-1 rounded-md text-xs hover:bg-blue-600"><Truck className="inline-block w-3 h-3 mr-1" /> Dispatch</button>
                  )}
                  {activeOrderTab === 'dispatched' && (
                    <button className="bg-purple-500 text-white px-3 py-1 rounded-md text-xs hover:bg-purple-600"><Package className="inline-block w-3 h-3 mr-1" /> Complete</button>
                  )}
                  <button className="bg-red-500 text-white px-3 py-1 rounded-md text-xs hover:bg-red-600"><XCircle className="inline-block w-3 h-3 mr-1" /> Cancel</button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-gray-500 text-center py-8">No {activeOrderTab} orders at the moment.</p>
        )}
      </div>
    </section>
  );
};

export default LiveOrders;